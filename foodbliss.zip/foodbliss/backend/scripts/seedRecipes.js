const mongoose = require('mongoose');
const Recipe = require('../models/Recipe'); // Adjust the path if necessary
require('dotenv').config({ path: '../.env' }); // Ensure it points to the correct .env file

const connectDB = async () => {
    try {
        const uri = process.env.MONGODB_URI || "mongodb+srv://foodbliss_admin:Durga@cluster0.gojck.mongodb.net/foodblissDB?retryWrites=true&w=majority";
        await mongoose.connect(uri);
        console.log('MongoDB connected successfully');
    } catch (err) {
        console.error('MongoDB connection failed:', err.message);
    }
};

const seedRecipes = async () => {
    await connectDB();

    const sampleRecipes = [
        {
            name: "Chicken Manchurian",
            ingredients: ["chicken", "cornflour", "flour", "ginger-garlic paste", "soy sauce", "seasonings", "onions", "green chilies", "sauces", "water", "spring onions"],
            instructions: [
                "Marinate the chicken with cornflour, flour, ginger-garlic paste, soy sauce, and seasonings for 15-20 minutes.",
                "Fry marinated chicken until golden and crispy. Set aside.",
                "Prepare the sauce: sauté onions, green chilies, ginger-garlic paste, then add sauces and water. Thicken with cornflour.",
                "Combine fried chicken with the sauce, cook for 2-3 minutes. Adjust seasoning and garnish with spring onions.",
                "Serve hot with rice or noodles. Enjoy your Chicken Manchurian!"
            ]
        },
        {
            name: "Creamy Pasta",
            ingredients: ["pasta", "cream", "cheese"],
            instructions: [
                "Step 1: Cook pasta according to package instructions.",
                "Step 2: In a pan, mix cooked pasta with cream and cheese until well combined."
            ]
        },
        {
            name: "Healthy Salad",
            ingredients: ["lettuce", "tomato", "cucumber"],
            instructions: [
                "Step 1: Wash and chop lettuce, tomato, and cucumber.",
                "Step 2: Combine all ingredients in a bowl and add your favorite dressing."
            ]
        },
        {
            name: "Chocolate Cake",
            ingredients: ["flour", "sugar", "chocolate"],
            instructions: [
                "Step 1: Preheat oven to 350°F (175°C).",
                "Step 2: Mix flour, sugar, and chocolate in a bowl.",
                "Step 3: Bake the mixture in the oven for 25-30 minutes."
            ]
        }
    ];

    await Recipe.insertMany(sampleRecipes);
    console.log("Sample recipes added to the database.");
    mongoose.connection.close();
};

seedRecipes();
