// backend/routes/recipeRoutes.js
const express = require('express');
const router = express.Router();
const Recipe = require('/models/Recipe');

// Define your recipe routes here

module.exports = router;