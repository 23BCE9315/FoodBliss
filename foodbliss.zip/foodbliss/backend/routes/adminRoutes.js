// Admin Login Route
app.post('/admin-login', async (req, res) => {
    const { email, password } = req.body;
    try {
        const user = await User.findOne({ email });
        if (!user || !user.isAdmin || !(await bcrypt.compare(password, user.password))) {
            return res.status(401).json({ message: "Invalid admin credentials" });
        }
        req.session.user = { email: user.email, isAdmin: user.isAdmin }; // Store user in session
        res.json({ message: "Admin login successful!" });
    } catch (err) {
        console.error("Admin login error:", err);
        res.status(500).json({ message: "Server error" });
    }
});
