const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const path = require('path');
const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const User = require('./models/User');
const Recipe = require('./models/Recipe');
require('dotenv').config();
const session = require('express-session');

const app = express();
const port = process.env.PORT || 5000;

// Connect to MongoDB

const connectDB = async () => {
    try {
        const uri = process.env.MONGODB_URI || "mongodb+srv://foodbliss_admin:Durga@cluster0.gojck.mongodb.net/foodblissDB?retryWrites=true&w=majority";
        console.log('MongoDB URI:', uri);
        await mongoose.connect(uri);
        console.log('MongoDB connected successfully');
    } catch (err) {
        console.error('MongoDB connection failed:', err.message);
    }
};


// Connect to the database
connectDB();

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, '../public')));
app.use(session({
    secret: 'secretkey',
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false } // Set to true in production with HTTPS
}));

// Routes
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, '../public', 'index.html'));
});


app.post('/register', async (req, res) => {
    const { email, password } = req.body;
    console.log("Registration request received:", req.body);

    if (!email || !password) {
        return res.status(400).json({ message: "Email and password are required!" });
    }

    try {
        const existingUser = await User.findOne({ email });
        if (existingUser) {
            return res.status(400).json({ message: "User already exists!" });
        }

        const hashedPassword = await bcrypt.hash(password, 10);
        const newUser = new User({ email, password: hashedPassword });
        await newUser.save();
        res.json({ message: "Registration successful!" });
    } catch (err) {
        console.error("Registration error:", err);
        res.status(500).json({ message: "Server error", error: err.message });
    }
});
app.post('/register', async (req, res) => {
    const { email, password } = req.body;
    console.log("Registration request received:", req.body);

    if (!email || !password) {
        return res.status(400).json({ message: "Email and password are required!" });
    }

    try {
        const existingUser = await User.findOne({ email });
        if (existingUser) {
            return res.status(400).json({ message: "User already exists!" });
        }

        const hashedPassword = await bcrypt.hash(password, 10);
        const newUser = new User({ email, password: hashedPassword });
        await newUser.save();
        res.json({ message: "Registration successful!" });
    } catch (err) {
        console.error("Registration error:", err);
        res.status(500).json({ message: "Server error", error: err.message });
    }
});


// User login endpoint
app.post('/login', async (req, res) => {
    const { email, password } = req.body;
    try {
        const user = await User.findOne({ email });
        if (!user || !(await bcrypt.compare(password, user.password))) {
            console.log("Login failed for user:", email);
            return res.status(401).json({ message: "Login failed!" });
        }
        console.log("Login successful for user:", email);
        req.session.user = { email: user.email }; // Store user email in session
        res.json({ message: "Login successful!", email: user.email });
    } catch (err) {
        console.error("Login error:", err);
        res.status(500).json({ message: "Server error", error: err.message });
    }
});
// Admin Login Route
app.post('/admin-login', async (req, res) => {
    const { email, password } = req.body;
    try {
        const user = await User.findOne({ email });
        if (!user || !user.isAdmin || !(await bcrypt.compare(password, user.password))) {
            console.log("Admin login failed for user:", email);
            return res.status(401).json({ message: "Invalid admin credentials" });
        }
        console.log("Admin login successful for user:", email);
        req.session.user = { email: user.email, isAdmin: user.isAdmin }; // Store user email and admin status in session
        res.json({ message: "Admin login successful!", email: user.email });
    } catch (err) {
        console.error("Admin login error:", err);
        res.status(500).json({ message: "Server error", error: err.message });
    }
});




// Endpoint to find recipes based on ingredients
app.get('/find-recipes', async (req, res) => {
    const { ingredients } = req.query;
    if (!ingredients) {
        return res.status(400).json({ message: "Ingredients query parameter is required!" });
    }

    console.log("Ingredients received:", ingredients);

    try {
        const ingredientArray = ingredients.split(',').map(ingredient => ingredient.trim().toLowerCase());
        console.log("Ingredient array:", ingredientArray);

        const foundRecipes = await Recipe.find({
            ingredients: { $elemMatch: { $in: ingredientArray } }
        });

        console.log("Found recipes:", foundRecipes);

        if (foundRecipes.length === 0) {
            return res.json({ message: "No recipes found for the given ingredients.", recipes: [] });
        }

        res.json({ recipes: foundRecipes });
    } catch (err) {
        console.error("Error finding recipes:", err);
        res.status(500).json({ message: "Server error" });
    }
});

// Order food endpoint
app.post('/order-food', (req, res) => {
    const { items, deliveryAddress, quantity, specialRequests } = req.body;

    if (!Array.isArray(items) || items.length === 0) {
        return res.status(400).json({ message: "Items should be a non-empty array!" });
    }

    console.log("Received order items:", items);
    console.log("Delivery Address:", deliveryAddress);
    console.log("Quantity:", quantity);
    console.log("Special Requests:", specialRequests);

    // Process the order (e.g., save to database, send confirmation, etc.)

    res.json({ message: `Order for ${items.join(', ')} placed successfully!` });
});

// Contact form submission endpoint
app.post('/contact', (req, res) => {
    const { name, email, message } = req.body;

    if (!name || !email || !message) {
        return res.status(400).json({ message: "All fields are required!" });
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        return res.status(400).json({ message: "Invalid email format!" });
    }

    console.log("Contact form submission received:", { name, email, message });

    res.json({ message: "Message received! We will get back to you soon." });
});

// About endpoint
app.get('/about', (req, res) => {
    res.json({ content: "Welcome to Food Bliss! We help you find delicious recipes and order food easily." });
});

// Admin Middleware
const authMiddleware = (req, res, next) => {
    if (req.session.user && req.session.user.isAdmin) {
        next();
    } else {
        res.status(403).json({ message: "Forbidden" });
    }
};

// Admin Routes
const adminRoutes = express.Router();

// Apply middleware to all admin routes
adminRoutes.use(authMiddleware);

// Admin route to get all users
adminRoutes.get('/users', async (req, res) => {
    try {
        const users = await User.find();
        res.json(users);
    } catch (err) {
        res.status(500).json({ message: "Server error" });
    }
});

// Admin route to add a user
adminRoutes.post('/users', async (req, res) => {
    const { email, password, isAdmin } = req.body;
    try {
        if (!email || !password) {
            return res.status(400).json({ message: "Email and password are required!" });
        }

        const existingUser = await User.findOne({ email });
        if (existingUser) {
            return res.status(400).json({ message: "User already exists!" });
        }

        const hashedPassword = await bcrypt.hash(password, 10);
        const newUser = new User({ email, password: hashedPassword, isAdmin });
        await newUser.save();
        res.json({ message: "User added successfully" });
    } catch (err) {
        console.error("Error adding user:", err);
        res.status(500).json({ message: "Server error", error: err.message });
    }
});


// Admin route to update a user
adminRoutes.put('/users/:id', async (req, res) => {
    const { id } = req.params;
    const { email, password, isAdmin } = req.body;

    console.log(`Updating user with ID: ${id}`);
    console.log(`Received data: ${JSON.stringify({ email, password, isAdmin })}`);

    try {
        const user = await User.findById(id);
        if (!user) {
            console.log(`User not found with ID: ${id}`);
            return res.status(404).json({ message: "User not found" });
        }

        // Update user details
        user.email = email;
        if (password) { // Only update password if it is provided
            console.log("Updating password");
            user.password = await bcrypt.hash(password, 10);
        } else {
            console.log("Password not provided, skipping password update");
        }
        user.isAdmin = isAdmin;

        await user.save();
        console.log("User updated successfully");
        res.json({ message: "User updated successfully" });
    } catch (err) {
        console.error("Error updating user:", err);
        res.status(500).json({ message: "Server error", error: err.message });
    }
});


// Admin route to delete a user
adminRoutes.delete('/users/:id', async (req, res) => {
    const { id } = req.params;
    try {
        await User.findByIdAndDelete(id);
        res.json({ message: "User deleted successfully" });
    } catch (err) {
        res.status(500).json({ message: "Server error" });
    }
});

// Admin route to get all recipes
adminRoutes.get('/recipes', async (req, res) => {
    try {
        const recipes = await Recipe.find();
        res.json(recipes);
    } catch (err) {
        res.status(500).json({ message: "Server error" });
    }
});

// Admin route to add a recipe
adminRoutes.post('/recipes', async (req, res) => {
    const { name, ingredients, instructions } = req.body;
    try {
        const newRecipe = new Recipe({ name, ingredients, instructions });
        await newRecipe.save();
        res.json({ message: "Recipe added successfully" });
    } catch (err) {
        res.status(500).json({ message: "Server error" });
    }
});

// Admin route to update a recipe
adminRoutes.put('/recipes/:id', async (req, res) => {
    const { id } = req.params;
    const { name, ingredients, instructions } = req.body;
    try {
        const recipe = await Recipe.findById(id);
        if (!recipe) {
            return res.status(404).json({ message: "Recipe not found" });
        }
        recipe.name = name;
        recipe.ingredients = ingredients;
        recipe.instructions = instructions;
        await recipe.save();
        res.json({ message: "Recipe updated successfully" });
    } catch (err) {
        res.status(500).json({ message: "Server error" });
    }
});

// Admin route to delete a recipe
adminRoutes.delete('/recipes/:id', async (req, res) => {
    const { id } = req.params;
    try {
        await Recipe.findByIdAndDelete(id);
        res.json({ message: "Recipe deleted successfully" });
    } catch (err) {
        res.status(500).json({ message: "Server error" });
    }
});

// Admin Login Route
app.post('/admin-login', async (req, res) => {
    const { email, password } = req.body;
    try {
        const user = await User.findOne({ email });
        if (!user || !user.isAdmin || !(await bcrypt.compare(password, user.password))) {
            return res.status(401).json({ message: "Invalid admin credentials" });
        }
        req.session.user = { email: user.email, isAdmin: user.isAdmin }; // Store user in session
        res.json({ message: "Admin login successful!" });
    } catch (err) {
        console.error("Admin login error:", err);
        res.status(500).json({ message: "Server error" });
    }
});

// Use admin routes
app.use('/api/admin', adminRoutes);

// Start the server
app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
