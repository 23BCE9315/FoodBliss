const mongoose = require('mongoose');

const RecipeSchema = new mongoose.Schema({
    name: { type: String, required: true },
    ingredients: [{ type: String }],
    instructions: [{ type: String }] // Store instructions as an array of steps
});

module.exports = mongoose.model('Recipe', RecipeSchema);
