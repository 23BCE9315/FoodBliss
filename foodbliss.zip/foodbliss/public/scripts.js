document.addEventListener("DOMContentLoaded", function () {
    const findRecipesBtn = document.getElementById("findRecipesBtn");
    if (findRecipesBtn) {
        findRecipesBtn.addEventListener("click", findRecipes);
    }

    document.body.addEventListener("click", function (event) {
        if (event.target && event.target.classList.contains("view-recipe")) {
            viewRecipe(event.target.getAttribute("data-name"));
        }
        if (event.target && event.target.classList.contains("order-recipe")) {
            orderRecipe(event.target.getAttribute("data-name"));
        }
    });

    const contactForm = document.getElementById("contactForm");
    if (contactForm) {
        contactForm.addEventListener("submit", sendContact);
    }

    const loginForm = document.getElementById("loginForm");
    if (loginForm) {
        loginForm.addEventListener("submit", handleLogin);
    }

    const registerForm = document.getElementById("registerForm");
    if (registerForm) {
        registerForm.addEventListener("submit", handleRegister);
    }

    const addUserForm = document.getElementById("addUserForm");
    if (addUserForm) {
        addUserForm.addEventListener("submit", handleAddUser);
    }

    const addRecipeForm = document.getElementById("addRecipeForm");
    if (addRecipeForm) {
        addRecipeForm.addEventListener("submit", handleAddRecipe);
    }

    // Fetch users and recipes on page load
    fetchUsers();
    fetchRecipes();
});

let selectedRecipe = null;
let foundRecipes = [];

function findRecipes() {
    let ingredients = document.getElementById("recipeInput").value.trim();
    console.log("Searching for recipes with ingredients:", ingredients);

    fetch(`http://localhost:5000/find-recipes?ingredients=${ingredients}`)
        .then(response => response.json())
        .then(data => {
            console.log("Data received from server:", data);
            const resultDiv = document.getElementById("recipeResults");
            if (data.recipes && data.recipes.length > 0) {
                resultDiv.innerHTML = `Recipes found: <div>${data.recipes.map(r => `
                    <div class="recipe-card">
                        <h5>${r.name}</h5>
                        <p>${r.instructions}</p>
                        <button class="btn btn-primary view-recipe" data-name="${r.name}">View Recipe</button>
                        <button class="btn btn-success order-recipe" data-name="${r.name}">Order Now</button>
                    </div>`).join("")}</div>`;
                foundRecipes = data.recipes;
            } else {
                resultDiv.innerHTML = "No recipes found for the given ingredients.";
                foundRecipes = [];
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('There was an error finding recipes!');
        });
}

function viewRecipe(recipeName) {
    let recipe = foundRecipes.find(r => r.name === recipeName);
    if (!recipe) {
        console.error("Recipe not found:", recipeName);
        return;
    }

    let recipeDetailsDiv = document.getElementById("recipeDetails");
    recipeDetailsDiv.innerHTML = `
        <div class="recipe-card">
            <h5>${recipe.name}</h5>
            <p>${recipe.instructions}</p>
        </div>
    `;
    recipeDetailsDiv.style.display = "block";

    document.getElementById("recipeNameModal").innerText = recipe.name;
    document.getElementById("ingredientsListModal").innerHTML = recipe.ingredients.split(", ").map(ingredient => `<li>${ingredient}</li>`).join("");
    document.getElementById("recipeInstructionsModal").innerText = recipe.instructions;
    const recipeModal = new bootstrap.Modal(document.getElementById("recipeModal"));
    recipeModal.show();
}

function orderRecipe(recipeName) {
    selectedRecipe = recipeName;
    document.getElementById("orderConfirmation").style.display = "block";
    document.getElementById("orderConfirmation").innerText = "Your order for " + selectedRecipe + " has been placed successfully!";
}

function handleLogin(event) {
    event.preventDefault();
    let email = document.getElementById("email").value;
    let password = document.getElementById("password").value;

    fetch("http://localhost:5000/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password })
    })
    .then(response => response.json())
    .then(data => {
        alert(data.message);
        if (data.message === "Login successful!") {
    if (data.user.isAdmin) {
        window.location.href = "/admin-dashboard.html";
    } else {
        window.location.href = "/home.html";
    }
}

    })
    .catch(error => {
        console.error('Error:', error);
        alert('Something went wrong. Please try again!');
    });
}

function handleRegister(event) {
    event.preventDefault();
    let email = document.getElementById("regEmail").value;
    let password = document.getElementById("regPassword").value;

    fetch("http://localhost:5000/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password })
    })
    .then(response => response.json())
    .then(data => {
        alert(data.message);
        if (data.message === "Registration successful!") {
            toggleLogin();
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Something went wrong. Please try again!');
    });
}

function sendContact(event) {
    event.preventDefault();

    const contactForm = new FormData(event.target);
    const name = contactForm.get('name');
    const email = contactForm.get('email');
    const message = contactForm.get('message');

    fetch("http://localhost:5000/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, email, message })
    })
    .then(response => response.json())
    .then(data => {
        alert(data.message);
        event.target.reset();
    })
    .catch(error => {
        console.error('Error:', error);
        alert('There was an error sending your message!');
    });
}

async function fetchUsers() {
    try {
        const response = await fetch('/api/admin/users', {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json'
            }
        });
        const data = await response.json();
        const usersList = document.getElementById('usersList');
        usersList.innerHTML = data.map(user => `
            <div>
                <p>Email: ${user.email}</p>
                <p>Admin: ${user.isAdmin}</p>
                <button class="btn btn-warning" onclick="editUser('${user._id}', '${user.email}', ${user.isAdmin})">Edit</button>
                <button class="btn btn-danger" onclick="deleteUser('${user._id}')">Delete</button>
            </div>
        `).join('');
    } catch (error) {
        console.error('Error fetching users:', error);
    }
}

async function fetchRecipes() {
    try {
        const response = await fetch('/api/admin/recipes', {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json'
            }
        });
        const data = await response.json();
        const recipesList = document.getElementById('recipesList');
        recipesList.innerHTML = data.map(recipe => `
            <div>
                <h4>${recipe.name}</h4>
                <p>Ingredients: ${recipe.ingredients.join(', ')}</p>
                <p>Instructions: ${recipe.instructions.join(', ')}</p>
                <button class="btn btn-warning" onclick="editRecipe('${recipe._id}')">Edit</button>
                <button class="btn btn-danger" onclick="deleteRecipe('${recipe._id}')">Delete</button>
            </div>
        `).join('');
    } catch (error) {
        console.error('Error fetching recipes:', error);
    }
}

async function handleAddUser(event) {
    event.preventDefault();
    const email = document.getElementById('userEmail').value;
    const password = document.getElementById('userPassword').value;
    const isAdmin = document.getElementById('userIsAdmin').checked;

    try {
        const response = await fetch('/api/admin/users', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ email, password, isAdmin })
        });
        const data = await response.json();
        alert(data.message);
        fetchUsers();
        document.getElementById('addUserModal').querySelector('.btn-close').click();
    } catch (error) {
        console.error('Error adding user:', error);
        alert('There was an error adding the user.');
    }
}

async function handleAddRecipe(event) {
    event.preventDefault();
    const name = document.getElementById('recipeName').value;
    const ingredients = document.getElementById('recipeIngredients').value.split(',');
    const instructions = document.getElementById('recipeInstructions').value.split('\n');

    try {
        const response = await fetch('/api/admin/recipes', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ name, ingredients, instructions })
        });
        const data = await response.json();
        alert(data.message);
        fetchRecipes();
        document.getElementById('addRecipeModal').querySelector('.btn-close').click();
    } catch (error) {
        console.error('Error adding recipe:', error);
        alert('There was an error adding the recipe.');
    }
}

// Function to edit a user
function editUser(userId, userEmail, isAdmin) {
    document.getElementById('editUserId').value = userId;
    document.getElementById('editUserEmail').value = userEmail;
    document.getElementById('editUserIsAdmin').checked = isAdmin;
    document.getElementById('editUserPassword').value = ''; // Clear password field
    const editUserModal = new bootstrap.Modal(document.getElementById('editUserModal'));
    editUserModal.show();
}

// Function to update a user
document.getElementById('editUserForm').addEventListener('submit', async function(event) {
    event.preventDefault();
    const userId = document.getElementById('editUserId').value;
    const email = document.getElementById('editUserEmail').value;
    const password = document.getElementById('editUserPassword').value;
    const isAdmin = document.getElementById('editUserIsAdmin').checked;

    try {
        const response = await fetch(`/api/admin/users/${userId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password, isAdmin })
        });
        const data = await response.json();
        if (response.ok) {
            alert(data.message);
            fetchUsers();
            document.getElementById('editUserModal').querySelector('.btn-close').click();
        } else {
            alert(`Error: ${data.message}`);
        }
    } catch (error) {
        console.error('Error updating user:', error);
        alert('There was an error updating the user.');
    }
});



// Function to delete a user
async function deleteUser(userId) {
    try {
        const response = await fetch(`/api/admin/users/${userId}`, {
            method: 'DELETE',
            headers: { 'Content-Type': 'application/json' }
        });
        const data = await response.json();
        alert(data.message);
        fetchUsers();
    } catch (error) {
        console.error('Error deleting user:', error);
        alert('There was an error deleting the user.');
    }
}

// Function to edit a recipe
function editRecipe(recipeId) {
    // Implement the logic to edit a recipe
    console.log("Edit recipe with ID:", recipeId);
    // You can fetch the recipe data and populate a form for editing
}

// Function to delete a recipe
async function deleteRecipe(recipeId) {
    try {
        const response = await fetch(`/api/admin/recipes/${recipeId}`, {
            method: 'DELETE',
            headers: { 'Content-Type': 'application/json' }
        });
        const data = await response.json();
        alert(data.message);
        fetchRecipes();
    } catch (error) {
        console.error('Error deleting recipe:', error);
        alert('There was an error deleting the recipe.');
    }
}
